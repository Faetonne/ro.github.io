<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="Fountain : NC State Dining" />
<meta name="description" content="Fountain : NC State Dining" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Fountain : NC State Dining</title>
<link href='http://fonts.googleapis.com/css?family=Nova+Mono' rel='stylesheet' type='text/css' />
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />


</head>
<body  id="Yh5L3BHg7joVWz">
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header">
			<div id="logo">
				<h1><a href="#">fountain</a></h1>
			</div>
		</div>
	</div>
	<!-- end #header -->
	<div id="menu">
		<ul>
			<li class="current_page_item"><a href="#">Home</a></li>
			<li><a href="privacy-policy.html">Privacy policy</a></li>
			<li><a href="terms.html">Terms and Conditions</a></li>
			<li><a href="photo.html">Photo gallery</a></li>
			<li><a href="contact.html">Contacts</a></li>
		</ul>
	</div>
	<!-- end #menu -->
	<div id="page">
		<div id="page-bgtop">
			<div id="page-bgbtm">
				<div id="content">
					<div class="post">
						<h2 class="title"><a href="#">Fountain : NC State Dining</a></h2>
						<p class="meta">Posted by <a href="#">Someone</a> 2021.07.16 17:49
							&nbsp;&bull;&nbsp; <a href="#" class="comments">Comments (64)</a> &nbsp;&bull;&nbsp; <a href="#" class="permalink">Full article</a></p>
						<div class="entry">
							<p><img src="img/05b34747e2ca28549201634022143913.jpg" width="186" height="186" alt="" class="alignleft border" />
							<br>
							<hr />
<iframe width="100%" height="315" src="https://www.youtube.com/embed/zhpIxz43gNE"><div class="mc_vtvc_th b_canvas"><div class="cico" style="width:234px;height:131px;"><div class="rms_iac" style="height:131px;line-height:131px;width:234px;" data-height="131" data-width="234" data-alt="Fountain 32 Fever" data-role="presentation" data-class="rms_img" data-src="https://tse3.mm.bing.net/th?id=OVP.o5gCOKh5p1-gazN-GuQhCAEsDh" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe><br>		<img src="img/dd51444da9afe0b5190d467bb43a35bb.jpg" width="50%"/>
							</div>
					</div>
					<div style="clear: both;">&nbsp;</div>
				</div>
				<!-- end #content -->
				<div id="sidebar">
					<ul>
						<li>
							<h2 id="pzFfVHzFDKzXI">Blog</h2>
							<p id="JnkH7I4HyvHVV1">About</p>
						</li>
						<li>
							<h2>Categories</h2>
<ul><li><a href="index.html">'Fountain', Marcel Duchamp, 1917, replica 1964 | Tate</a><br> </li><li><a href="cat1.html">Reed N. Fountain - Young Moore Attorneys</a><br> </li><li><a href="cat2.html">Home | The Fountain of Raleigh Fellowship Church</a><br> </li><li><a href="cat3.html">Fountain - Wikipedia</a><br> </li><li><a href="cat4.html">Outdoor Fountains | Amazon.com</a><br> </li><li><a href="cat5.html">Fountain | Definition of Fountain by Merriam-Webster</a><br> </li><li><a href="cat6.html">Outdoor Fountains at Lowes.com</a><br> </li><li><a href="cat7.html">Fountains - Outdoor Decor - The Home Depot</a><br> </li><li><a href="cat8.html">Fountains for Home or Office - Decorative Water Fountains .</a><br> </li><li><a href="cat9.html">Fountain : NC State Dining</a><br> </li></ul>
						</li>
						<li>
							<h2 id="LFPp1Av7SW6IGzq">Photo #1</h2>
		<img src="img/8766b8334199a7322c70a40ccf3147ee.jpg" width="50%" id="pyJ2YubsAnYu"/>
						<li>
							<h2 id="jHW4WiVjaynzUJs">Menu</h2>
		<ul><li><a href="index.html">'Fountain', Marcel Duchamp, 1917, replica 1964 | Tate</a></li><li><a href="cat1.html">Reed N. Fountain - Young Moore Attorneys</a><br></li><li><a href="cat2.html">Home | The Fountain of Raleigh Fellowship Church</a><br></li><li><a href="cat3.html">Fountain - Wikipedia</a><br></li><li><a href="cat4.html">Outdoor Fountains | Amazon.com</a><br></li><li><a href="cat5.html">Fountain | Definition of Fountain by Merriam-Webster</a><br></li><li><a href="cat6.html">Outdoor Fountains at Lowes.com</a><br></li><li><a href="cat7.html">Fountains - Outdoor Decor - The Home Depot</a><br></li><li><a href="cat8.html">Fountains for Home or Office - Decorative Water Fountains .</a><br></li><li><a href="cat9.html">Fountain : NC State Dining</a><br></li></ul>
						</li>
					</ul>
				</div>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
		</div>
	</div>
	<!-- end #page -->
</div>
<div id="footer">
	<p>&copy; fountain. All rights reserved. Design by TEMPLATED.</p>
	<p></p>
</div>
<!-- end #footer -->
</body>
</html>
